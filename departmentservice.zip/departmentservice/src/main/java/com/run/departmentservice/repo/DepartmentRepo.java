package com.run.departmentservice.repo;

import com.run.departmentservice.entity.DepartmentEntity;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Repository
public class DepartmentRepo{
    private List<DepartmentEntity> departments = new ArrayList<>();

    public DepartmentEntity addDepartment(DepartmentEntity departmentEntity){
            departments.add(departmentEntity);
            return departmentEntity;
    }

    public DepartmentEntity findById(Long id){
        return departments.stream()
                .filter(departmentEntity -> Objects.equals(departmentEntity.getId(), id))
                .findFirst()
                .orElseThrow();
    }

    public List<DepartmentEntity> findAll(){
        return departments;
    }
}
