package com.run.departmentservice.controller;

import com.run.departmentservice.client.EmployeeClient;
import com.run.departmentservice.entity.DepartmentEntity;
import com.run.departmentservice.repo.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    private DepartmentRepo departmentRepo;

    @Autowired
    private EmployeeClient employeeClient;

    @PostMapping
    public DepartmentEntity add(@RequestBody DepartmentEntity departmentEntity){
        return departmentRepo.addDepartment(departmentEntity);
    }

    @GetMapping
    public List<DepartmentEntity> findAll(){
        return departmentRepo.findAll();
    }

    @GetMapping("/{id}")
    public DepartmentEntity findById(@PathVariable Long id){
        return departmentRepo.findById(id);
    }

    @GetMapping("/with-employees")
    public List<DepartmentEntity> findAllWithEmployees(){
       List<DepartmentEntity> departmentEntities
               =departmentRepo.findAll();
       departmentEntities.forEach(departmentEntity -> departmentEntity.setEmployees(employeeClient.findByDepartment(departmentEntity.getId())));
        return departmentEntities;
    }
}
