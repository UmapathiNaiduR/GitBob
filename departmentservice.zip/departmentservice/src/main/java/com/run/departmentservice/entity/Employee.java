package com.run.departmentservice.entity;

public record Employee(Long id, Long departmentId, String name, int age, String position) {

    //By default this record is final and all the properties will be created using constructor and it won't have any setter but having getters to connect

}
