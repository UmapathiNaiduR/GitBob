package com.run.departmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
