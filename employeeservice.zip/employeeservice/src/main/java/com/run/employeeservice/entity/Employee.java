package com.run.employeeservice.entity;

public record Employee(Long id, Long departmentId, String name, int age, String position) {

    //By default this record is final and all the properties will be created using constructor and it wont have any setter but having getters to connect

}
