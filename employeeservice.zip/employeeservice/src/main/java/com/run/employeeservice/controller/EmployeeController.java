package com.run.employeeservice.controller;

import com.run.employeeservice.entity.Employee;
import com.run.employeeservice.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeRepo employeeRepo;

    @PostMapping
    public Employee add(@RequestBody Employee employee){
        return employeeRepo.add(employee);
    }

    @GetMapping
    public List<Employee> findAll(){
        return employeeRepo.findAll();
    }

    @GetMapping("/{id}")
    public Employee findById(@PathVariable Long id){
        return employeeRepo.findById(id);
    }

    @GetMapping("/department/{departmentId}")
    public List<Employee> findByDepartment(@PathVariable("departmentId") Long departmentId){
        return employeeRepo.findByDepartment(departmentId);
    }

}
